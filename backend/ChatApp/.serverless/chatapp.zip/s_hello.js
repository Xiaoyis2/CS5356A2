
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'xiaoyis2',
  applicationName: 'my-dynamo-app',
  appUid: 'd9RnGKRDfXQHD5nf1V',
  orgUid: '8a4d1158-3e16-4518-9e0e-e48af3c7f6d5',
  deploymentUid: 'f7184d67-a2fc-4437-a2df-406f111a309b',
  serviceName: 'chatapp',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'chatapp-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}